In order to open the index file and load the webpage you will need to start a server in the folder.

1.You can do this by installing python on Windows or if you have a Mac it is already installed.

2.Open up a terminal in windows or mac and navigate to your folder.

3. Once in your folder type the command:
	python -m SimpleHTTPServer

4.Hit Enter

5.In your browser go to:
	localhost:8000/index.html